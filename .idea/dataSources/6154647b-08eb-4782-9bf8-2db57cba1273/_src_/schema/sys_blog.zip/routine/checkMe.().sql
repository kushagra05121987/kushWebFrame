CREATE PROCEDURE checkMe()
  begin
    set @rInOut2 = @rInOut2 + 2;
end;
