CREATE PROCEDURE callMe()
  begin
    set @a = 1;
end;
