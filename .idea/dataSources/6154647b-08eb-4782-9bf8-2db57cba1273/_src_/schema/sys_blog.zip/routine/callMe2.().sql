CREATE PROCEDURE callMe2()
  begin
    select 20 into @val;
    select @val;
    insert into test values (1,"Ban");
end;
