CREATE FUNCTION checkFunction()
  RETURNS INT
  begin
	set @rInOut2 = @rInOut2 + 2;
    return @rInOut2;
end;
