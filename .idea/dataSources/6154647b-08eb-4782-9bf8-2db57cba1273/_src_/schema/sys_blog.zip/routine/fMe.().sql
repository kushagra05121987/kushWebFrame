CREATE FUNCTION fMe()
  RETURNS INT
  begin
	call callMe();
    return 1;
end;
